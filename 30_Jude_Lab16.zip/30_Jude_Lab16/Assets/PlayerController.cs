﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    float Speed = 10f;
    float RotateSpeed = 100f;

    public GameObject bulletSpawn;
    public GameObject bulletPrefab;
    public GameObject EnemyChecker;
    public Text Score;
    int score;

    // Start is called before the first frame update
    void Start()
    {
        Score.GetComponent<Text>().text = "Score: " + score;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W) || (Input.GetKey(KeyCode.UpArrow)))
        {
            transform.position += transform.forward * Speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.S) || (Input.GetKey(KeyCode.DownArrow)))
        {
            transform.position -= transform.forward * Speed * Time.deltaTime;
        }

        if(Input.GetKey(KeyCode.A) || (Input.GetKey(KeyCode.LeftArrow)))
        {
            transform.Rotate(-new Vector3(0, Time.deltaTime * RotateSpeed, 0));
        }

        if (Input.GetKey(KeyCode.D) || (Input.GetKey(KeyCode.RightArrow)))
        {
            transform.Rotate(new Vector3(0, Time.deltaTime * RotateSpeed, 0));
        }


        if(Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(bulletPrefab, bulletSpawn.transform.position, transform.rotation);
        }

        if (EnemyChecker == null)
        {
            score += 1;
        }
    }
}
