﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    public GameObject healthText;
    public float speed;
    public float rotateSpeed;
    public float damageRate;
    public float health;
    public Animator animator;
        
        
    // Start is called before the first frame update
    void Start()
    {
        healthText.GetComponent<Text>().text = "Health: " + health;
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W) && (health >= 0) || (Input.GetKey(KeyCode.UpArrow) && (health >= 0)))
        {
            transform.position += transform.forward * speed * Time.deltaTime;
            animator.SetBool("IsWalk", true);
        }

        else if (Input.GetKeyUp(KeyCode.W) || (Input.GetKeyUp(KeyCode.DownArrow)))
        {
            animator.SetBool("IsWalk", false);
        }


        if (Input.GetKey(KeyCode.S) && (health >= 0) || (Input.GetKey(KeyCode.DownArrow) && (health >= 0)))
        {
            transform.position -= transform.forward * speed * Time.deltaTime;
            animator.SetBool("IsWalk", true);
        }

        else if (Input.GetKeyUp(KeyCode.S) || (Input.GetKeyUp(KeyCode.DownArrow)))
        {
            animator.SetBool("IsWalk", false);
        }

        if (Input.GetKey(KeyCode.D) && (health >= 0) || (Input.GetKey(KeyCode.RightArrow) && (health >= 0)))
        {
            transform.Rotate(new Vector3(0, Time.deltaTime * rotateSpeed, 0));
        }

        if (Input.GetKey(KeyCode.A) && (health >= 0) || (Input.GetKey(KeyCode.LeftArrow) && (health >= 0)))
        {
            transform.Rotate(-new Vector3(0, Time.deltaTime * rotateSpeed, 0));
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            animator.SetTrigger("AttackTrigger");
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Fire")
        {
            health -= damageRate * Time.deltaTime;
            healthText.GetComponent<Text>().text = "Health: " + health;
        }

        if (health <= 0)
        {
            animator.SetTrigger("DeadTrigger");
        }
    }
}
