﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Character : MonoBehaviour
{
    public float MoveSpeed;
    public float JumpForce;

    public int healthCount;
    public int coinCount;

    private Rigidbody2D rb;
    private Animator animator;

    public Text healthText;
    public Text coinsCollected;

    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {

        audioSource.GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        healthText.GetComponent<Text>().text = "Health: " + healthCount;
        coinsCollected.GetComponent<Text>().text = "Coins: " + coinCount;

    }

    // Update is called once per frame
    void Update()
    {
        healthText.GetComponent<Text>().text = "Health: " + healthCount;
        coinsCollected.GetComponent<Text>().text = "Coins: " + coinCount;

        float hVelocity = 0;
        float vvelocity = 0;

        if(Input.GetKey(KeyCode.LeftArrow))
        {
            animator.SetFloat("xVelocity", Mathf.Abs(hVelocity));
            hVelocity -= MoveSpeed;
            transform.localScale = new Vector3(-1, 1, 1);
        }

        else if(Input.GetKey(KeyCode.RightArrow))
        {
            animator.SetFloat("xVelocity", 0);
            hVelocity = MoveSpeed;
            transform.localScale = new Vector3(1, 1, 1);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            animator.SetTrigger("JumpTrigger");
            vvelocity = JumpForce;
            audioSource.Play();
        }

        if (Input.GetKeyUp(KeyCode.Space))
        {
            audioSource.Stop();
        }


        hVelocity = Mathf.Clamp(rb.velocity.x + hVelocity, -5, 5);

        rb.velocity = new Vector2(hVelocity, rb.velocity.y + vvelocity);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            healthCount -= 10;
        }

        else if (collision.gameObject.tag == "Coin")
        {
            coinCount += 1;
            Destroy(collision.gameObject);
        }
    }
}
