﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float Speed;
    public float rotateSpeed;
    public Text Red;
    public Text Purple;
    public Text Yellow;
    public Text Orange;
    int Red1 = 0;
    int Purple1 = 0;
    int Yellow1 = 0;
    int Orange1 = 0;
    Rigidbody rb;

    private AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float Position = transform.position.y;

        Red.text = ("Red: " + Red1);
        Purple.text = ("Purple: " + Purple1);
        Yellow.text = ("Yellow: " + Yellow1);
        Orange.text = ("Orange: " + Orange1);

        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.up * Speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.position -= transform.up * Speed * Time.deltaTime;
        }

        if(Input.GetKey(KeyCode.D))
        {
            transform.position += transform.right * Speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.position -= transform.right * Speed * Time.deltaTime;
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.collider.tag == "Red")
        {
            Red1++;
            audioSource.Play();
        }

       else if (collision.collider.tag == "Purple")
        {
            Purple1 += 1;
            audioSource.Play();
        }

       else if (collision.collider.tag == "Yellow")
        {
            Yellow1 += 1;
            audioSource.Play();
        }

       else if (collision.collider.tag == "Orange")
        {
            Orange1 += 1;
            audioSource.Play();
        }
    }
}
