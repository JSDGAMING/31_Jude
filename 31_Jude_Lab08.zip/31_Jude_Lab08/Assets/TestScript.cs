﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TestScript : MonoBehaviour
{
    float SpacebarPressed = 0f;
    public GameObject scoreText;
    // Start is called before the first frame update
    void Start()
    {
        scoreText.GetComponent<Text>().text = ("Spacebar Pressed: " + SpacebarPressed);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SpacebarPressed += 1;
            print("Spacebar pressed: " + SpacebarPressed);
            scoreText.GetComponent<Text>().text = ("Spacebar Pressed: " + SpacebarPressed);
        }
    }
}
